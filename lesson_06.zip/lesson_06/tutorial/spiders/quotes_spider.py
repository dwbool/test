from pathlib import Path

import scrapy

import pymongo
from pymongo import MongoClient

import sqlite3


#  scrapy crawl quotes -O quotes.json

#import scrapy
from scrapy_splash import SplashRequest


import scrapy

#https://gist.github.com/stummjr/d2d6b561334051214238cb705ced9f92


# this example needs the scrapyjs package: pip install scrapyjs
# it also needs a splash instance running in your env or on Scrapy Cloud (https://github.com/scrapinghub/splash)
class QuotesSpider(scrapy.Spider):
    name = 'quotes'
    download_delay = 3

    con = 0
    cur = 0

    def __init__(self):
        print("////////////////////////////////////////")
        print("///  in constructors only we trust  ////")
        print("////////////////////////////////////////")
        self.con = sqlite3.connect("tutorial.db")
        self.cur = self.con.cursor()
        try:
            self.cur.execute("CREATE TABLE movie(title, year, score)")
        except:
            pass
        self.cur.execute("insert into movie(title, year, score) values ('ccc','1999','11')")
        self.cur.execute("insert into movie(title, year, score) values ('ddd','1999','11')")
        self.con.commit()

    def start_requests(self):
        yield scrapy.Request(
            'http://quotes.toscrape.com/js', self.parse,
            meta={
               'splash': {
                   'endpoint': 'render.html',
               }
            }
        )

    def parse(self, response):
        print(response.body)
        for quote in response.css('.quote'):
            self.cur.execute("insert into movie(title, year, score) values ('%s','%s','$s')" % (quote.css('span::text').extract_first(),quote.css('small::text').extract_first(),quote.css('.tags a::text').extract()))
            self.con.commit()
            yield {
                'text': quote.css('span::text').extract_first(),
                'author': quote.css('small::text').extract_first(),
                'tags': quote.css('.tags a::text').extract(),
            }




'''
class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = ["http://example.com", "http://example.com/foo"]

    def start_requests(self):
        for url in self.start_urls:
            yield SplashRequest(url, self.parse,
                                endpoint='render.html',
                                args={'wait': 0.5},
                                )

    def parse(self, response):
        print(response)
'''

# response.body is a result of render.html call; it
# contains HTML processed by a browser.
# …


'''
class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        #'https://www.carrefoursa.com/'
        'https://www.superjob.ru/vacancy/search/?keywords=Delphi%20developer&geo%5Bt%5D%5B0%5D=4'

    ]

    def __init__(self):
        print("////////////////////////////////////////")
        print("///  in constructors only we trust  ////")
        print("////////////////////////////////////////")

        con = sqlite3.connect("tutorial.db")
        cur = con.cursor()
        #cur.execute("CREATE TABLE movie(title, year, score)")
        cur.execute("insert into movie(title, year, score) values ('ccc','1999','11')" )
        cur.execute("insert into movie(title, year, score) values ('ddd','1999','11')")
        con.commit()

   
    def parse___old(self, response):
        page = response.url.split("/")[-2]
        filename = f'quotes-{page}.html'
        Path(filename).write_bytes(response.body)
        self.log(f'Saved file {filename}')
 

    def parse(self, response):
        for quote in response.css('div'):
            yield {
                'text': quote.css('div.f-test-vacancy-item').getall(),
                    #quote.css('span.item-name').getall(),
                #'author': quote.css('small.author::text').get(),
                #'tags': quote.css('div.tags a.tag::text').getall(),

                #'aaa1': quote.css('a::text').get(),
                #'aaa2': quote.css('a::attr(href)').get(),

            }
            
'''

'''
class QuotesSpider(scrapy.Spider):
    name = "quotes"

    def start_requests(self):
        urls = [
            'https://quotes.toscrape.com/page/1/',
            'https://quotes.toscrape.com/page/2/',
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = f'quotes-{page}.html'
        Path(filename).write_bytes(response.body)
        self.log(f'Saved file {filename}')

'''
