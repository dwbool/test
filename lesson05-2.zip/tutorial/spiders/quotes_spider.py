from pathlib import Path

import scrapy

import pymongo
from pymongo import MongoClient


#  scrapy crawl quotes -O quotes.json

class QuotesSpider(scrapy.Spider):
    name = "quotes"
    start_urls = [
        'https://www.carrefoursa.com/'

    ]
    '''
    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = f'quotes-{page}.html'
        Path(filename).write_bytes(response.body)
        self.log(f'Saved file {filename}')
    '''

    def parse(self, response):
        for quote in response.css('div.row'):
            yield {
                'text': quote.css('span.item-name').getall(),
                #'author': quote.css('small.author::text').get(),
                #'tags': quote.css('div.tags a.tag::text').getall(),

                #'aaa1': quote.css('a::text').get(),
                #'aaa2': quote.css('a::attr(href)').get(),

            }
            


'''
class QuotesSpider(scrapy.Spider):
    name = "quotes"

    def start_requests(self):
        urls = [
            'https://quotes.toscrape.com/page/1/',
            'https://quotes.toscrape.com/page/2/',
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = f'quotes-{page}.html'
        Path(filename).write_bytes(response.body)
        self.log(f'Saved file {filename}')

'''
